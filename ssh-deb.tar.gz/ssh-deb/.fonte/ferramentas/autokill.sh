#while :
 # do 
  #./userlimit.sh 1 
  #sleep 5 
  #done
#while :
  #do
  #userlimit 2
  #sleep 55 
  #done
while :
  do
  userexpired
  sleep 36000
  done
