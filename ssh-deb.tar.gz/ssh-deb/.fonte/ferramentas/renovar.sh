#!/bin/bash
echo "-----------------------------------"
echo "  RENOVAÇÂO  "
echo "-----------------------------------"
echo -n "Username: "
read akun
echo -n "Validade em dias: "
read exp
IP=`ifconfig eth0| awk 'NR==2 {print $2}'| awk -F: '{print $2}'`
chage -I -1 -E `date -d "$exp days" +"%Y-%m-%d"` $akun
echo "-----------------------------------------------------"
echo "  RENOVADO COM SUCESSO  "
echo "-----------------------------------------------------"
echo -e "Username: $akun "
echo -e "Válido por: $exp dias"
echo -e "IP: $IP "
echo -e "PortaSSH: 443 "
echo -e "PortaSquid: 80 "
echo "-----------------------------------------------------"
