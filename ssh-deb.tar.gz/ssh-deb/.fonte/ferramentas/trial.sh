#!/bin/bash

Login=TRIAL`</dev/urandom tr -dc X-Z0-9 | head -c4`
hari="1"
Pass=`</dev/urandom tr -dc a-f0-9 | head -c9`
IP=`ifconfig eth0| awk 'NR==2 {print $2}'| awk -F: '{print $2}'`
useradd -e `date -d "$hari days" +"%Y-%m-%d"` -s /bin/false -M -g trial $Login
echo -e "$Pass\n$Pass\n"|passwd $Login &> /dev/null
echo -e ""
echo -e "==== CRIADO COM SUCESSO ===="
echo -e "Username : $Login"
echo -e "Senha: $Pass\n"
echo -e "Válido por: 1 dia"
echo -e "IP: $IP "
echo -e "PortaSquid: 80 "
echo -e "PortaSSH: 443 "
echo -e "============================"
echo -e ""
